import numpy as np
import matplotlib.pyplot as plt

epochs = 150
true_acc = 0.97
initial_acc = 0.33
acc_curve = initial_acc + (true_acc - initial_acc) * (1 - np.exp(-0.05 * np.arange(epochs)))
noise = np.random.normal(0, 0.01, size=epochs)
simulated_acc = np.clip(acc_curve + noise, 0, 1)

plt.figure(figsize=(8, 4))
plt.plot(simulated_acc, label='Simulated Accuracy (ANN)')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.title('ANN Learning Curve Simulation')
plt.legend()
plt.tight_layout()
plt.savefig("/mnt/data/ann_accuracy_simulation.png", dpi=300)