import numpy as np
import matplotlib.pyplot as plt

steps = 100
alpha = 0.1
gamma = 0.5

actions = np.random.choice([-1, 0, 1], size=(steps,))
price_changes = np.zeros(steps)
volatility = []

for n in range(1, steps):
    noise = np.random.randn() * 0.5
    influence = np.mean(actions[max(0, n-5):n]) + noise
    price_changes[n] = influence
    std_window = np.std(price_changes[max(0, n-5):n+1])
    volatility.append(std_window)

plt.figure(figsize=(8, 4))
plt.plot(volatility, label='Simulated Volatility Φ(S⁽ⁿ⁾)')
plt.xlabel('Time step')
plt.ylabel('Volatility')
plt.title('Market Volatility Simulation')
plt.legend()
plt.tight_layout()
plt.savefig("/mnt/data/market_volatility_simulation.png", dpi=300)