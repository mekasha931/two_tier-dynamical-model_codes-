import numpy as np
import matplotlib.pyplot as plt

N = 20
steps = 50
alpha = 0.2
eta = 0.3

positions = np.random.rand(N, 2) * 10
gradients = np.random.randn(N, 2)
S_values = []

for n in range(steps):
    K = np.exp(-alpha * np.arange(n + 1)[::-1])
    alignment_vector = np.mean(gradients, axis=0)
    S = np.linalg.norm(alignment_vector)
    for i in range(N):
        noise = np.random.randn(2)
        positions[i] += -gradients[i] + eta * S * noise
    S_values.append(S)

plt.figure(figsize=(8, 4))
plt.plot(S_values, label='Simulated ECM Alignment S⁽ⁿ⁾')
plt.xlabel('Time step')
plt.ylabel('ECM Alignment')
plt.title('ECM Morphogenesis Simulation')
plt.legend()
plt.tight_layout()
plt.savefig("/mnt/data/ecm_morphogenesis_simulation.png", dpi=300)