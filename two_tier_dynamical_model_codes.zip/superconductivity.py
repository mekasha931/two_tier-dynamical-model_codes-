import numpy as np
import matplotlib.pyplot as plt

# Parameters
N = 100
T = 10
dt = 0.1
steps = int(T / dt)
alpha = 0.3
beta = 0.5

theta = np.random.uniform(0, 2 * np.pi, N)
S_values = []

for n in range(steps):
    K = np.exp(-alpha * np.arange(n + 1)[::-1] * dt)
    for i in range(N):
        interaction_sum = 0
        for j in range(N):
            if i != j:
                interaction_sum += np.sin(theta[j] - theta[i])
        memory_sum = np.sum(K * interaction_sum)
        S = np.abs(np.sum(np.exp(1j * theta)) / N)
        theta[i] += dt * (memory_sum + beta * S * np.sin(-theta[i]))
    S_values.append(S)

plt.figure(figsize=(8, 4))
plt.plot(np.arange(steps) * dt, S_values, label='Simulated Coherence S(t)')
plt.xlabel('Time')
plt.ylabel('Coherence')
plt.title('Superconductivity Simulation')
plt.legend()
plt.tight_layout()
plt.savefig("/mnt/data/superconductivity_simulation.png", dpi=300)